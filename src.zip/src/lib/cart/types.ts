import type { EyeRx } from "../../components/cart/RxBlock";

export type RxData = {
  expires: string;
  right?: EyeRx;
  left?: EyeRx;
};

export type CartOrder = {
  id: string;
  rx: RxData | null;
  sku: string | null;

  box_count: number | null;
  right_box_count?: number | null;
  left_box_count?: number | null;

  total_amount_cents: number | null;

  shipping_cents?: number | null;
};

export type PowerSegment = {
  min: number; // inclusive
  max: number; // inclusive
  step: 0.25 | 0.5 | 1;
};

export type PowerSpec = {
  segments: PowerSegment[];
  allowPlano?: boolean; // default true
  planoLabel?: "PL" | "Plano" | "+0.00";
};
